<?php 
hakAkses(['admin']); 
$now = date('Y-m-d'); 

$barang = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(*) AS total FROM tb_barang"));
$barang_masuk = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(*) AS total FROM tb_transaksi WHERE jenis_transaksi = 'masuk'"));
$barang_keluar = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(*) AS total FROM tb_transaksi WHERE jenis_transaksi = 'keluar'"));
$barang_pinjam = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(*) AS total FROM tb_transaksi WHERE jenis_transaksi = 'pinjam'"));
?>

<style>
    

    

    .container-fluid {
        padding-top: 20px;
        padding-bottom: 20px;
        background-image: url('assets/img/sekolah.jpeg');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        min-height: 100vh;
        padding: 0;
        margin: 0;
    }

    .card {
        background-color: rgba(255, 255, 255, 0.85);
        border: none;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
        margin-bottom: -10px;
    }

    .card-header {
        font-weight: bold;
    }

    h1.h3 {
        color: #343a40;
        font-weight: 600;
    }
    .marquee-container {
    overflow: hidden;
    white-space: nowrap;
    box-sizing: border-box;
    color: white;
    padding: 10px;
    font-weight: bold;
}

.marquee-text {
    display: inline-block;
    padding-left: 100%;
    animation: marquee 15s linear infinite;
}

@keyframes marquee {
    0%   { transform: translateX(0); }
    100% { transform: translateX(-100%); }
}
.bg-success{
    background-color: yellow;
}
</style>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        
    </div>
    <div class="marquee-container">
    <div class="marquee-text">
        "Kreatif, Mandiri dan Berprestasi"
    </div>
</div>

    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    Data Barang
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= $barang['total']; ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-header bg-warning text-white">
                    Barang Masuk
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= $barang_masuk['total']; ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-header bg-success text-white">
                    Barang Keluar
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= $barang_keluar['total']; ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card">
                <div class="card-header bg-info text-white">
                    Peminjaman
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= $barang_pinjam['total']; ?></h5>
                     
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->


            <footer class="py-7 bg-light mt-auto">                    
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Collaboration &copy;  Universitas Muhammadiyah Brebes 2025 </div>
                            <div>