<?php
session_start();
include ('../config/conn.php');
include ('../config/function.php');

function gantiPassword($conn, $userId, $passwordLama, $passwordBaru, $konfirmasiPassword) {
    // Validasi form
    if (empty($passwordLama) || empty($passwordBaru) || empty($konfirmasiPassword)) {
        return ['status' => false, 'message' => 'Semua field harus diisi.'];
    }

    if ($passwordBaru !== $konfirmasiPassword) {
        return ['status' => false, 'message' => 'Password baru dan konfirmasi tidak cocok.'];
    }

    // Ambil password lama dari DB
    $stmt = $conn->prepare("SELECT password FROM tb_user WHERE id_user = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($hashedPassword);
    $stmt->fetch();
    $stmt->close();

    // Verifikasi password lama
    if (!password_verify($passwordLama, $hashedPassword)) {
        return ['status' => false, 'message' => 'Password lama salah.'];
    }

    // Hash password baru
    $newHashedPassword = password_hash($passwordBaru, PASSWORD_DEFAULT);

    // Update ke database
    $stmt = $conn->prepare("UPDATE tb_user SET password = ? WHERE id_user = ?");
    $stmt->bind_param("si", $newHashedPassword, $userId);
    $success = $stmt->execute();
    $stmt->close();

    if ($success) {
        return ['status' => true, 'message' => 'Password berhasil diganti.'];
    } else {
        return ['status' => false, 'message' => 'Gagal mengganti password.'];
    }
}

// Jalankan fungsi jika tombol diklik
if (isset($_POST['ganti_password'])) {
    $userId = $_SESSION['user_id']; // pastikan user_id tersimpan di session
    $passwordLama = $_POST['password_lama'];
    $passwordBaru = $_POST['password_baru'];
    $konfirmasiPassword = $_POST['konfirmasi_password'];

    $result = gantiPassword($conn, $userId, $passwordLama, $passwordBaru, $konfirmasiPassword);

    if ($result['status']) {
        $_SESSION['success'] = $result['message'];
        header("Location: ../login.php"); // arahkan ke login agar login ulang
        exit;
    } else {
        $_SESSION['error'] = $result['message'];
        header("Location: ../index.php");
        exit;
    }
}
?>
