<?php
session_start();

// Asumsikan user sudah login dan punya session user_id
// Contoh:
$_SESSION['user_id'] = 1; // ini hanya untuk demo. Sesuaikan di login sesungguhnya

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $userId = $_SESSION['user_id'];
    $currentPassword = $_POST['currentPassword'];
    $newPassword = $_POST['newPassword'];
    $confirmPassword = $_POST['confirmPassword'];

    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        echo "Semua field harus diisi.";
        exit;
    }

    if ($newPassword !== $confirmPassword) {
        echo "Password baru dan konfirmasi tidak cocok.";
        exit;
    }

    // Koneksi ke database
    $conn = new mysqli("localhost", "root", "", "user_db");

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Ambil password lama dari database
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($hashedPassword);
    $stmt->fetch();
    $stmt->close();

    // Verifikasi password lama
    if (!password_verify($currentPassword, $hashedPassword)) {
        echo "Password lama salah.";
        $conn->close();
        exit;
    }

    // Hash password baru
    $newHashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update ke database
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $newHashedPassword, $userId);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    echo "Password berhasil diganti.";
} else {
    echo "Akses tidak valid.";
}
?>
