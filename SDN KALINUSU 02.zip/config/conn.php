<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "db_sisarpras";

$con = mysqli_connect($hostname, $username, $password, $database);

// Cek koneksi
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
