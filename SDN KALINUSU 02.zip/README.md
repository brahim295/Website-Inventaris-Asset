Sistem informasi sarana prasarana inventaris barang sekolah mi sederhana menggunakan php native


## Preview

![Preview 1](https://raw.githubusercontent.com/snowfluke/sistem-informasi-sarana-prasarana-inventaris-barang-sekolah-mi-php/main/screenshots/Screenshot_2023-09-13-23-39-25_5296.png)
